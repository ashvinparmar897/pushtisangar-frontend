import React from "react";
import "./MObileSidebar.css";
import Sidebar from './Sidebar'



function MobileSidebar() {
  return (
 
      <Sidebar/>
      
    
  );
}

export default MobileSidebar;
